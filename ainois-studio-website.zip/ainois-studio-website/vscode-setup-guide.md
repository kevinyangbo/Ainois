# VS Code 快速设置指南 - Ainois Studio 网站开发

## 🚀 快速开始（5分钟设置）

### 第一步：安装必需扩展

打开VS Code，按 `Ctrl+Shift+X` 打开扩展面板，搜索并安装：

```
1. Live Server (ritwickdey.liveserver)
2. HTML CSS Support (ecmel.vscode-html-css)
3. JavaScript (ES6) code snippets (xabikos.javascriptsnippets)
4. Prettier - Code formatter (esbenp.prettier-vscode)
5. Auto Rename Tag (formulahendry.auto-rename-tag)
```

### 第二步：打开项目

1. 解压下载的 `ainois-studio-website.tar.gz`
2. 在VS Code中：`File` → `Open Folder` → 选择解压后的文件夹

### 第三步：启动开发服务器

1. 右键点击 `index.html` 文件
2. 选择 `Open with Live Server`
3. 浏览器自动打开网站（通常是 `http://localhost:5500`）

## 🎯 项目文件说明

```
ainois-studio-website/
├── index.html          ← 主页面（右键用Live Server打开）
├── css/
│   └── style.css      ← 样式文件（修改外观）
├── js/
│   └── script.js      ← 功能文件（修改交互）
├── images/            ← 图片文件夹
└── assets/            ← 其他资源
```

## ✏️ 常用修改任务

### 1. 修改公司信息

**文件**: `index.html`
**位置**: 搜索 "Ainois Studio"

```html
<!-- 修改公司名称 -->
<div class="logo-text">Your Studio Name</div>

<!-- 修改联系邮箱 -->
<a href="mailto:hello@ainois-studio.com">your-email@domain.com</a>

<!-- 修改电话号码 -->
<a href="tel:+6512345678">+65 1234 5678</a>
```

### 2. 修改颜色主题

**文件**: `css/style.css`
**搜索**: `#6366f1` 和 `#8b5cf6`

```css
/* 原来的紫色 */
background: linear-gradient(135deg, #6366f1, #8b5cf6);

/* 改为蓝色 */
background: linear-gradient(135deg, #3b82f6, #1d4ed8);

/* 改为绿色 */
background: linear-gradient(135deg, #10b981, #059669);

/* 改为橙色 */
background: linear-gradient(135deg, #f59e0b, #d97706);
```

### 3. 添加YouTube视频

**文件**: `index.html`
**位置**: 搜索 "portfolio-item"

```html
<div class="portfolio-item" data-category="2d-animation">
    <div class="portfolio-video">
        <div class="video-placeholder" data-video-id="YOUR_YOUTUBE_VIDEO_ID">
            <img src="https://img.youtube.com/vi/YOUR_VIDEO_ID/maxresdefault.jpg" alt="Video thumbnail">
            <div class="play-button">
                <svg>...</svg>
            </div>
        </div>
    </div>
    <div class="portfolio-info">
        <h3 class="portfolio-title">Your Project Name</h3>
        <p class="portfolio-description">Project description here</p>
        <div class="portfolio-tags">
            <span class="tag">2D Animation</span>
            <span class="tag">Brand Story</span>
        </div>
    </div>
</div>
```

**获取YouTube视频ID**:
- YouTube链接: `https://www.youtube.com/watch?v=dQw4w9WgXcQ`
- 视频ID: `dQw4w9WgXcQ` (等号后面的部分)

### 4. 修改服务内容

**文件**: `index.html`
**位置**: 搜索 "service-card"

```html
<div class="service-card">
    <div class="service-icon">
        <!-- 可以在 https://heroicons.com/ 找到图标 -->
        <svg>...</svg>
    </div>
    <h3 class="service-title" data-en="Your Service" data-zh="您的服务">Your Service</h3>
    <p class="service-description" data-en="Service description" data-zh="服务描述">Service description here</p>
</div>
```

### 5. 修改多语言内容

**文件**: `js/script.js`
**位置**: 搜索 "translations"

```javascript
const translations = {
    en: {
        'Your Text': 'Your Text',
        'Another Text': 'Another Text'
    },
    zh: {
        'Your Text': '您的文本',
        'Another Text': '另一个文本'
    }
};
```

## 🔧 VS Code 实用快捷键

```bash
Ctrl + S           # 保存文件
Ctrl + F           # 查找文本
Ctrl + H           # 查找并替换
Ctrl + D           # 选择相同内容
Ctrl + /           # 注释/取消注释
Alt + Shift + F    # 格式化代码
Ctrl + `           # 打开终端
F12                # 转到定义
```

## 🌐 实时预览和测试

### Live Server 功能
- ✅ 自动刷新：修改代码后浏览器自动更新
- ✅ 移动端测试：可以在手机上访问
- ✅ 多设备同步：所有设备同时更新

### 移动端测试
1. 确保电脑和手机在同一WiFi网络
2. Live Server启动后，查看终端显示的IP地址
3. 在手机浏览器输入：`http://192.168.x.x:5500`

### 浏览器开发者工具
- **F12** 打开开发者工具
- **Ctrl+Shift+M** 切换移动端视图
- **Elements** 面板：检查HTML和CSS
- **Console** 面板：查看JavaScript错误

## 🎨 设计资源

### 免费图标网站
- [Heroicons](https://heroicons.com/) - 简洁的SVG图标
- [Feather Icons](https://feathericons.com/) - 轻量级图标
- [Lucide](https://lucide.dev/) - 现代图标库

### 颜色工具
- [Coolors.co](https://coolors.co/) - 配色方案生成器
- [Adobe Color](https://color.adobe.com/) - 专业配色工具
- [Color Hunt](https://colorhunt.co/) - 流行配色方案

### 字体资源
- [Google Fonts](https://fonts.google.com/) - 免费网络字体
- 当前使用：Inter（正文）+ Playfair Display（标题）

## 🚨 常见问题解决

### 问题1：Live Server无法启动
**解决方案**：
1. 确保已安装Live Server扩展
2. 右键点击HTML文件，不是文件夹
3. 检查端口是否被占用

### 问题2：修改后页面没有更新
**解决方案**：
1. 检查文件是否已保存（Ctrl+S）
2. 刷新浏览器（F5）
3. 清除浏览器缓存（Ctrl+Shift+R）

### 问题3：CSS样式不生效
**解决方案**：
1. 检查CSS文件路径是否正确
2. 查看浏览器控制台是否有错误
3. 确认CSS选择器是否正确

### 问题4：JavaScript功能不工作
**解决方案**：
1. 打开浏览器控制台（F12）
2. 查看Console面板的错误信息
3. 检查JavaScript文件是否正确加载

## 📱 响应式测试清单

在VS Code中测试不同屏幕尺寸：

```bash
# 桌面端
- 1920x1080 (大屏幕)
- 1366x768 (笔记本)
- 1024x768 (小桌面)

# 平板端
- 768x1024 (iPad竖屏)
- 1024x768 (iPad横屏)

# 手机端
- 375x667 (iPhone SE)
- 414x896 (iPhone 11)
- 360x640 (Android)
```

## 🔄 版本控制（可选）

如果要使用Git进行版本控制：

```bash
# 在VS Code终端中执行
git init
git add .
git commit -m "Initial commit"

# 每次修改后
git add .
git commit -m "Update: 描述你的修改"
```

## 📊 性能优化建议

### 图片优化
- 使用WebP格式（更小的文件大小）
- 压缩图片（推荐工具：TinyPNG）
- 使用适当的图片尺寸

### 代码优化
- 删除未使用的CSS规则
- 压缩JavaScript代码
- 使用CDN加载第三方库

## 🎯 下一步学习

掌握基础修改后，可以学习：

1. **CSS Grid/Flexbox** - 更好的布局控制
2. **JavaScript ES6+** - 现代JavaScript特性
3. **GSAP动画** - 专业动画效果
4. **响应式设计** - 移动端优化
5. **SEO优化** - 搜索引擎优化

## 📞 需要帮助？

如果遇到问题：
1. 查看浏览器控制台错误信息
2. 检查VS Code问题面板
3. 搜索相关技术文档
4. 参考完整的开发指南文档

---

**祝您开发愉快！** 🚀

