// Multi-language support
const translations = {
    en: {
        // Navigation
        'Home': 'Home',
        'About': 'About',
        'Services': 'Services',
        'Portfolio': 'Portfolio',
        'Contact': 'Contact',
        
        // Hero Section
        'Bringing Stories to Life': 'Bringing Stories to Life',
        'Through Animation & Motion Graphics': 'Through Animation & Motion Graphics',
        'Ainois Studio specializes in 2D/3D Animation, Motion Graphics, Creative Direction, Storyboarding, and Character Design. We create compelling visual narratives for brands worldwide.': 'Ainois Studio specializes in 2D/3D Animation, Motion Graphics, Creative Direction, Storyboarding, and Character Design. We create compelling visual narratives for brands worldwide.',
        'View Our Work': 'View Our Work',
        'Get In Touch': 'Get In Touch',
        'Scroll to explore': 'Scroll to explore',
        
        // Services Section
        'Our Services': 'Our Services',
        'We offer comprehensive animation and motion graphics services': 'We offer comprehensive animation and motion graphics services',
        '2D Animation': '2D Animation',
        'Traditional and digital 2D animation for commercials, explainer videos, and brand storytelling.': 'Traditional and digital 2D animation for commercials, explainer videos, and brand storytelling.',
        '3D Animation': '3D Animation',
        'Cutting-edge 3D animation and modeling for immersive visual experiences and product visualization.': 'Cutting-edge 3D animation and modeling for immersive visual experiences and product visualization.',
        'Motion Graphics': 'Motion Graphics',
        'Dynamic motion graphics and visual effects for digital marketing, presentations, and brand identity.': 'Dynamic motion graphics and visual effects for digital marketing, presentations, and brand identity.',
        'Creative Direction': 'Creative Direction',
        'Strategic creative direction and concept development for cohesive brand storytelling across all media.': 'Strategic creative direction and concept development for cohesive brand storytelling across all media.',
        'Storyboarding': 'Storyboarding',
        'Detailed storyboards and animatics to visualize and plan your animation projects effectively.': 'Detailed storyboards and animatics to visualize and plan your animation projects effectively.',
        'Character Design': 'Character Design',
        'Memorable character design and development for animation, games, and brand mascots.': 'Memorable character design and development for animation, games, and brand mascots.',
        
        // About Section
        'About Ainois Studio': 'About Ainois Studio',
        'Based in Singapore, Ainois Studio is a creative powerhouse dedicated to bringing imagination to life through exceptional animation and motion graphics. Our team of talented artists and storytellers combines technical expertise with boundless creativity to deliver visual experiences that captivate and inspire.': 'Based in Singapore, Ainois Studio is a creative powerhouse dedicated to bringing imagination to life through exceptional animation and motion graphics. Our team of talented artists and storytellers combines technical expertise with boundless creativity to deliver visual experiences that captivate and inspire.',
        'We believe that every brand has a unique story to tell, and we\'re passionate about helping you tell yours through the power of animation. From concept to completion, we work closely with our clients to ensure that every frame serves the narrative and every movement has purpose.': 'We believe that every brand has a unique story to tell, and we\'re passionate about helping you tell yours through the power of animation. From concept to completion, we work closely with our clients to ensure that every frame serves the narrative and every movement has purpose.',
        'Projects Completed': 'Projects Completed',
        'Years Experience': 'Years Experience',
        'Happy Clients': 'Happy Clients',
        
        // Portfolio Section
        'Our Work': 'Our Work',
        'Explore our latest animation and motion graphics projects': 'Explore our latest animation and motion graphics projects',
        'All': 'All',
        'Brand Storytelling Animation': 'Brand Storytelling Animation',
        'A compelling 2D animation that brings a brand\'s story to life with vibrant characters and smooth transitions.': 'A compelling 2D animation that brings a brand\'s story to life with vibrant characters and smooth transitions.',
        'Product Visualization': 'Product Visualization',
        'Stunning 3D product animation showcasing features and benefits with photorealistic rendering.': 'Stunning 3D product animation showcasing features and benefits with photorealistic rendering.',
        'Corporate Presentation': 'Corporate Presentation',
        'Dynamic motion graphics for corporate presentations with data visualization and smooth transitions.': 'Dynamic motion graphics for corporate presentations with data visualization and smooth transitions.',
        'Mascot Character Animation': 'Mascot Character Animation',
        'Lovable character design and animation for brand mascot with personality and charm.': 'Lovable character design and animation for brand mascot with personality and charm.',
        
        // Contact Section
        'Let\'s Create Together': 'Let\'s Create Together',
        'Ready to bring your vision to life? Get in touch with us to discuss your next animation project.': 'Ready to bring your vision to life? Get in touch with us to discuss your next animation project.',
        'Location': 'Location',
        'Email': 'Email',
        'Phone': 'Phone',
        'Name': 'Name',
        'Company': 'Company',
        'Service Interested': 'Service Interested',
        'Select a service': 'Select a service',
        'Message': 'Message',
        'Send Message': 'Send Message',
        
        // Footer
        'Bringing Stories to Life': 'Bringing Stories to Life',
        'About Us': 'About Us',
        'All rights reserved.': 'All rights reserved.'
    },
    zh: {
        // Navigation
        'Home': '首页',
        'About': '关于我们',
        'Services': '服务',
        'Portfolio': '作品集',
        'Contact': '联系我们',
        
        // Hero Section
        'Bringing Stories to Life': '让故事栩栩如生',
        'Through Animation & Motion Graphics': '通过动画和动态图形',
        'Ainois Studio specializes in 2D/3D Animation, Motion Graphics, Creative Direction, Storyboarding, and Character Design. We create compelling visual narratives for brands worldwide.': 'Ainois Studio专注于2D/3D动画、动态图形、创意指导、故事板和角色设计。我们为全球品牌创造引人入胜的视觉叙事。',
        'View Our Work': '查看作品',
        'Get In Touch': '联系我们',
        'Scroll to explore': '滚动探索',
        
        // Services Section
        'Our Services': '我们的服务',
        'We offer comprehensive animation and motion graphics services': '我们提供全面的动画和动态图形服务',
        '2D Animation': '2D动画',
        'Traditional and digital 2D animation for commercials, explainer videos, and brand storytelling.': '为广告、解说视频和品牌故事制作传统和数字2D动画。',
        '3D Animation': '3D动画',
        'Cutting-edge 3D animation and modeling for immersive visual experiences and product visualization.': '前沿的3D动画和建模，用于沉浸式视觉体验和产品可视化。',
        'Motion Graphics': '动态图形',
        'Dynamic motion graphics and visual effects for digital marketing, presentations, and brand identity.': '为数字营销、演示和品牌识别制作动态图形和视觉效果。',
        'Creative Direction': '创意指导',
        'Strategic creative direction and concept development for cohesive brand storytelling across all media.': '为所有媒体的连贯品牌故事提供战略创意指导和概念开发。',
        'Storyboarding': '故事板',
        'Detailed storyboards and animatics to visualize and plan your animation projects effectively.': '详细的故事板和动画预览，有效地可视化和规划您的动画项目。',
        'Character Design': '角色设计',
        'Memorable character design and development for animation, games, and brand mascots.': '为动画、游戏和品牌吉祥物设计和开发令人难忘的角色。',
        
        // About Section
        'About Ainois Studio': '关于Ainois Studio',
        'Based in Singapore, Ainois Studio is a creative powerhouse dedicated to bringing imagination to life through exceptional animation and motion graphics. Our team of talented artists and storytellers combines technical expertise with boundless creativity to deliver visual experiences that captivate and inspire.': 'Ainois Studio位于新加坡，是一个致力于通过卓越的动画和动态图形将想象力变为现实的创意工厂。我们的天才艺术家和故事讲述者团队将技术专长与无限创意相结合，提供令人着迷和鼓舞人心的视觉体验。',
        'We believe that every brand has a unique story to tell, and we\'re passionate about helping you tell yours through the power of animation. From concept to completion, we work closely with our clients to ensure that every frame serves the narrative and every movement has purpose.': '我们相信每个品牌都有独特的故事要讲述，我们热衷于通过动画的力量帮助您讲述您的故事。从概念到完成，我们与客户密切合作，确保每一帧都服务于叙事，每一个动作都有目的。',
        'Projects Completed': '完成项目',
        'Years Experience': '年经验',
        'Happy Clients': '满意客户',
        
        // Portfolio Section
        'Our Work': '我们的作品',
        'Explore our latest animation and motion graphics projects': '探索我们最新的动画和动态图形项目',
        'All': '全部',
        '2D Animation': '2D动画',
        '3D Animation': '3D动画',
        'Motion Graphics': '动态图形',
        'Character Design': '角色设计',
        'Brand Storytelling Animation': '品牌故事动画',
        'A compelling 2D animation that brings a brand\'s story to life with vibrant characters and smooth transitions.': '一个引人入胜的2D动画，通过生动的角色和流畅的过渡将品牌故事栩栩如生地呈现。',
        'Product Visualization': '产品可视化',
        'Stunning 3D product animation showcasing features and benefits with photorealistic rendering.': '令人惊叹的3D产品动画，通过逼真的渲染展示功能和优势。',
        'Corporate Presentation': '企业演示',
        'Dynamic motion graphics for corporate presentations with data visualization and smooth transitions.': '为企业演示制作的动态图形，包含数据可视化和流畅过渡。',
        'Mascot Character Animation': '吉祥物角色动画',
        'Lovable character design and animation for brand mascot with personality and charm.': '为品牌吉祥物设计和动画的可爱角色，充满个性和魅力。',
        
        // Contact Section
        'Let\'s Create Together': '让我们一起创造',
        'Ready to bring your vision to life? Get in touch with us to discuss your next animation project.': '准备将您的愿景变为现实？联系我们讨论您的下一个动画项目。',
        'Location': '位置',
        'Email': '邮箱',
        'Phone': '电话',
        'Name': '姓名',
        'Company': '公司',
        'Service Interested': '感兴趣的服务',
        'Select a service': '选择服务',
        'Storyboarding': '故事板',
        'Creative Direction': '创意指导',
        'Message': '留言',
        'Send Message': '发送消息',
        
        // Footer
        'Bringing Stories to Life': '让故事栩栩如生',
        'About Us': '关于我们',
        'All rights reserved.': '版权所有。'
    }
};

// Current language
let currentLang = 'en';

// Custom Cursor
let cursor;
let cursorTrails = [];
let mouseX = 0;
let mouseY = 0;

// DOM Elements
const navbar = document.getElementById('navbar');
const hamburger = document.getElementById('hamburger');
const navMenu = document.getElementById('nav-menu');
const langButtons = document.querySelectorAll('.lang-btn');
const portfolioFilters = document.querySelectorAll('.filter-btn');
const portfolioItems = document.querySelectorAll('.portfolio-item');
const videoModal = document.getElementById('video-modal');
const videoModalClose = document.getElementById('video-modal-close');
const videoContainer = document.getElementById('video-container');
const contactForm = document.getElementById('contact-form');

// Initialize the website
document.addEventListener('DOMContentLoaded', function() {
    initializeCustomCursor();
    initializeGSAP();
    initializeNavigation();
    initializeLanguageToggle();
    initializePortfolioFilters();
    initializeVideoModal();
    initializeContactForm();
    initializeSmoothScrolling();
    initializeScrollEffects();
});

// Custom Cursor Implementation
function initializeCustomCursor() {
    cursor = document.querySelector('.cursor');
    
    // Create cursor trails
    for (let i = 0; i < 5; i++) {
        const trail = document.createElement('div');
        trail.className = 'cursor-trail';
        document.body.appendChild(trail);
        cursorTrails.push({
            element: trail,
            x: 0,
            y: 0,
            delay: i * 0.1
        });
    }
    
    // Mouse move event
    document.addEventListener('mousemove', (e) => {
        mouseX = e.clientX;
        mouseY = e.clientY;
        
        // Update main cursor
        cursor.style.left = mouseX - 10 + 'px';
        cursor.style.top = mouseY - 10 + 'px';
        
        // Update trails with delay
        cursorTrails.forEach((trail, index) => {
            setTimeout(() => {
                trail.x += (mouseX - trail.x) * 0.3;
                trail.y += (mouseY - trail.y) * 0.3;
                trail.element.style.left = trail.x - 3 + 'px';
                trail.element.style.top = trail.y - 3 + 'px';
            }, trail.delay * 50);
        });
    });
    
    // Hover effects
    const hoverElements = document.querySelectorAll('a, button, .service-card, .portfolio-item');
    hoverElements.forEach(element => {
        element.addEventListener('mouseenter', () => {
            cursor.classList.add('hover');
        });
        
        element.addEventListener('mouseleave', () => {
            cursor.classList.remove('hover');
        });
    });
    
    // Click effect
    document.addEventListener('mousedown', () => {
        cursor.style.transform = 'scale(0.8)';
    });
    
    document.addEventListener('mouseup', () => {
        cursor.style.transform = 'scale(1)';
    });
}

// GSAP Animations
function initializeGSAP() {
    gsap.registerPlugin(ScrollTrigger);
    
    // Hero animations
    gsap.timeline()
        .from('.hero-title-main', { duration: 1, y: 50, opacity: 0, ease: 'power3.out' })
        .from('.hero-title-sub', { duration: 0.8, y: 30, opacity: 0, ease: 'power3.out' }, '-=0.5')
        .from('.hero-description', { duration: 0.8, y: 30, opacity: 0, ease: 'power3.out' }, '-=0.3')
        .from('.hero-buttons', { duration: 0.8, y: 30, opacity: 0, ease: 'power3.out' }, '-=0.3')
        .from('.floating-elements .element', { 
            duration: 1, 
            scale: 0, 
            opacity: 0, 
            ease: 'back.out(1.7)',
            stagger: 0.2 
        }, '-=0.5');
    
    // Section animations
    gsap.utils.toArray('.service-card').forEach((card, index) => {
        gsap.from(card, {
            scrollTrigger: {
                trigger: card,
                start: 'top 80%',
                end: 'bottom 20%',
                toggleActions: 'play none none reverse'
            },
            duration: 0.8,
            y: 50,
            opacity: 0,
            delay: index * 0.1,
            ease: 'power3.out'
        });
    });
    
    gsap.utils.toArray('.portfolio-item').forEach((item, index) => {
        gsap.from(item, {
            scrollTrigger: {
                trigger: item,
                start: 'top 80%',
                end: 'bottom 20%',
                toggleActions: 'play none none reverse'
            },
            duration: 0.8,
            y: 50,
            opacity: 0,
            delay: index * 0.1,
            ease: 'power3.out'
        });
    });
    
    // About section animation
    gsap.from('.about-text', {
        scrollTrigger: {
            trigger: '.about',
            start: 'top 70%',
            end: 'bottom 30%',
            toggleActions: 'play none none reverse'
        },
        duration: 1,
        x: -50,
        opacity: 0,
        ease: 'power3.out'
    });
    
    gsap.from('.about-visual', {
        scrollTrigger: {
            trigger: '.about',
            start: 'top 70%',
            end: 'bottom 30%',
            toggleActions: 'play none none reverse'
        },
        duration: 1,
        x: 50,
        opacity: 0,
        ease: 'power3.out'
    });
    
    // Contact section animation
    gsap.from('.contact-info', {
        scrollTrigger: {
            trigger: '.contact',
            start: 'top 70%',
            end: 'bottom 30%',
            toggleActions: 'play none none reverse'
        },
        duration: 1,
        x: -50,
        opacity: 0,
        ease: 'power3.out'
    });
    
    gsap.from('.contact-form-container', {
        scrollTrigger: {
            trigger: '.contact',
            start: 'top 70%',
            end: 'bottom 30%',
            toggleActions: 'play none none reverse'
        },
        duration: 1,
        x: 50,
        opacity: 0,
        ease: 'power3.out'
    });
}

// Navigation functionality
function initializeNavigation() {
    // Navbar scroll effect
    window.addEventListener('scroll', function() {
        if (window.scrollY > 50) {
            navbar.classList.add('scrolled');
        } else {
            navbar.classList.remove('scrolled');
        }
    });
    
    // Mobile menu toggle
    hamburger.addEventListener('click', function() {
        hamburger.classList.toggle('active');
        navMenu.classList.toggle('active');
        document.body.style.overflow = navMenu.classList.contains('active') ? 'hidden' : '';
    });
    
    // Close mobile menu when clicking on a link
    document.querySelectorAll('.nav-link').forEach(link => {
        link.addEventListener('click', function() {
            hamburger.classList.remove('active');
            navMenu.classList.remove('active');
            document.body.style.overflow = '';
        });
    });
    
    // Close mobile menu when clicking outside
    document.addEventListener('click', function(e) {
        if (!navbar.contains(e.target) && navMenu.classList.contains('active')) {
            hamburger.classList.remove('active');
            navMenu.classList.remove('active');
            document.body.style.overflow = '';
        }
    });
}

// Language toggle functionality
function initializeLanguageToggle() {
    langButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            const lang = this.getAttribute('data-lang');
            if (lang !== currentLang) {
                switchLanguage(lang);
            }
        });
    });
}

function switchLanguage(lang) {
    currentLang = lang;
    
    // Update language buttons
    langButtons.forEach(btn => {
        btn.classList.toggle('active', btn.getAttribute('data-lang') === lang);
    });
    
    // Update HTML lang attribute
    document.getElementById('html-root').setAttribute('lang', lang === 'zh' ? 'zh-CN' : 'en');
    
    // Update all translatable elements
    document.querySelectorAll('[data-en]').forEach(element => {
        const englishText = element.getAttribute('data-en');
        const chineseText = element.getAttribute('data-zh');
        
        if (lang === 'en' && englishText) {
            if (element.tagName === 'INPUT' || element.tagName === 'TEXTAREA') {
                element.placeholder = englishText;
            } else if (element.tagName === 'OPTION') {
                element.textContent = englishText;
            } else {
                element.textContent = englishText;
            }
        } else if (lang === 'zh' && chineseText) {
            if (element.tagName === 'INPUT' || element.tagName === 'TEXTAREA') {
                element.placeholder = chineseText;
            } else if (element.tagName === 'OPTION') {
                element.textContent = chineseText;
            } else {
                element.textContent = chineseText;
            }
        }
    });
    
    // Store language preference
    localStorage.setItem('preferred-language', lang);
}

// Portfolio filters
function initializePortfolioFilters() {
    portfolioFilters.forEach(filter => {
        filter.addEventListener('click', function() {
            const filterValue = this.getAttribute('data-filter');
            
            // Update active filter
            portfolioFilters.forEach(f => f.classList.remove('active'));
            this.classList.add('active');
            
            // Filter portfolio items
            portfolioItems.forEach(item => {
                const itemCategory = item.getAttribute('data-category');
                
                if (filterValue === 'all' || itemCategory === filterValue) {
                    gsap.to(item, { duration: 0.3, opacity: 1, scale: 1, display: 'block' });
                } else {
                    gsap.to(item, { duration: 0.3, opacity: 0, scale: 0.8, display: 'none' });
                }
            });
        });
    });
}

// Video modal functionality
function initializeVideoModal() {
    // Open video modal
    document.querySelectorAll('.video-placeholder').forEach(placeholder => {
        placeholder.addEventListener('click', function() {
            const videoId = this.getAttribute('data-video-id');
            openVideoModal(videoId);
        });
    });
    
    // Close video modal
    videoModalClose.addEventListener('click', closeVideoModal);
    videoModal.addEventListener('click', function(e) {
        if (e.target === videoModal) {
            closeVideoModal();
        }
    });
    
    // Close modal with Escape key
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && videoModal.classList.contains('active')) {
            closeVideoModal();
        }
    });
}

function openVideoModal(videoId) {
    const iframe = document.createElement('iframe');
    iframe.src = `https://www.youtube.com/embed/${videoId}?autoplay=1&rel=0`;
    iframe.allow = 'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture';
    iframe.allowFullscreen = true;
    
    videoContainer.innerHTML = '';
    videoContainer.appendChild(iframe);
    
    videoModal.classList.add('active');
    document.body.style.overflow = 'hidden';
}

function closeVideoModal() {
    videoModal.classList.remove('active');
    videoContainer.innerHTML = '';
    document.body.style.overflow = '';
}

// Contact form functionality
function initializeContactForm() {
    contactForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Get form data
        const formData = new FormData(this);
        const data = Object.fromEntries(formData);
        
        // Simple form validation
        if (!data.name || !data.email || !data.message) {
            showNotification('Please fill in all required fields.', 'error');
            return;
        }
        
        if (!isValidEmail(data.email)) {
            showNotification('Please enter a valid email address.', 'error');
            return;
        }
        
        // Simulate form submission
        const submitBtn = this.querySelector('button[type="submit"]');
        const originalText = submitBtn.textContent;
        
        submitBtn.textContent = currentLang === 'zh' ? '发送中...' : 'Sending...';
        submitBtn.disabled = true;
        
        // Simulate API call
        setTimeout(() => {
            showNotification(
                currentLang === 'zh' 
                    ? '消息发送成功！我们会尽快回复您。' 
                    : 'Message sent successfully! We\'ll get back to you soon.',
                'success'
            );
            
            this.reset();
            submitBtn.textContent = originalText;
            submitBtn.disabled = false;
        }, 2000);
    });
}

function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

function showNotification(message, type) {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.textContent = message;
    
    // Style the notification
    Object.assign(notification.style, {
        position: 'fixed',
        top: '2rem',
        right: '2rem',
        background: type === 'success' ? '#10b981' : '#ef4444',
        color: '#ffffff',
        padding: '1rem 2rem',
        borderRadius: '10px',
        boxShadow: '0 4px 20px rgba(0, 0, 0, 0.3)',
        zIndex: '9999',
        transform: 'translateX(100%)',
        transition: 'transform 0.3s ease',
        maxWidth: '300px',
        wordWrap: 'break-word'
    });
    
    document.body.appendChild(notification);
    
    // Animate in
    setTimeout(() => {
        notification.style.transform = 'translateX(0)';
    }, 100);
    
    // Remove after 5 seconds
    setTimeout(() => {
        notification.style.transform = 'translateX(100%)';
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 300);
    }, 5000);
}

// Smooth scrolling for anchor links
function initializeSmoothScrolling() {
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            const targetElement = document.querySelector(targetId);
            
            if (targetElement) {
                const offsetTop = targetElement.offsetTop - 80; // Account for fixed navbar
                
                window.scrollTo({
                    top: offsetTop,
                    behavior: 'smooth'
                });
            }
        });
    });
}

// Scroll effects
function initializeScrollEffects() {
    // Parallax effect for hero section
    window.addEventListener('scroll', function() {
        const scrolled = window.pageYOffset;
        const parallaxElements = document.querySelectorAll('.floating-elements .element');
        
        parallaxElements.forEach((element, index) => {
            const speed = 0.5 + (index * 0.1);
            const yPos = -(scrolled * speed);
            element.style.transform = `translateY(${yPos}px) rotate(${scrolled * 0.1}deg)`;
        });
    });
    
    // Add scroll-based animations to stats
    const stats = document.querySelectorAll('.stat-number');
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const target = entry.target;
                const finalValue = parseInt(target.textContent);
                animateCounter(target, 0, finalValue, 2000);
                observer.unobserve(target);
            }
        });
    });
    
    stats.forEach(stat => observer.observe(stat));
}

// Counter animation
function animateCounter(element, start, end, duration) {
    const startTime = performance.now();
    const suffix = element.textContent.replace(/[0-9]/g, '');
    
    function updateCounter(currentTime) {
        const elapsed = currentTime - startTime;
        const progress = Math.min(elapsed / duration, 1);
        
        const current = Math.floor(start + (end - start) * easeOutQuart(progress));
        element.textContent = current + suffix;
        
        if (progress < 1) {
            requestAnimationFrame(updateCounter);
        }
    }
    
    requestAnimationFrame(updateCounter);
}

function easeOutQuart(t) {
    return 1 - Math.pow(1 - t, 4);
}

// Utility functions
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Performance optimization
function lazyLoadImages() {
    const images = document.querySelectorAll('img[loading="lazy"]');
    
    if ('IntersectionObserver' in window) {
        const imageObserver = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const img = entry.target;
                    img.src = img.dataset.src || img.src;
                    img.classList.remove('lazy');
                    observer.unobserve(img);
                }
            });
        });
        
        images.forEach(img => imageObserver.observe(img));
    } else {
        // Fallback for older browsers
        images.forEach(img => {
            img.src = img.dataset.src || img.src;
        });
    }
}

// Initialize lazy loading
document.addEventListener('DOMContentLoaded', lazyLoadImages);

// Error handling
window.addEventListener('error', function(e) {
    console.error('JavaScript error:', e.error);
});

// Service Worker registration (for PWA capabilities)
if ('serviceWorker' in navigator) {
    window.addEventListener('load', function() {
        // Uncomment when service worker is implemented
        // navigator.serviceWorker.register('/sw.js')
        //     .then(registration => console.log('SW registered'))
        //     .catch(registrationError => console.log('SW registration failed'));
    });
}

