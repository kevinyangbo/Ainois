# Ainois Studio 网站开发指南

## 📋 项目概述

这是为新加坡动画设计工作室 Ainois Studio 开发的专业国际官网，采用现代静态网站技术栈，支持英文/中文双语，集成YouTube作品展示功能。

### 🎯 项目特色
- 🎨 专业动画工作室设计风格
- 📱 完全响应式布局（桌面/平板/手机）
- 🌍 英文/中文双语切换
- 🎬 YouTube视频作品展示
- ⚡ 高性能静态网站
- 🔧 现代化交互动画效果

## 📁 项目结构

```
ainois-studio-website/
├── index.html              # 主页面文件
├── css/
│   └── style.css          # 主样式表
├── js/
│   └── script.js          # JavaScript功能文件
├── images/                # 图片资源文件夹
├── assets/                # 其他资源文件夹
└── README.md              # 项目说明文件
```

## 🛠️ 技术栈

### 前端技术
- **HTML5**: 语义化标记，SEO友好
- **CSS3**: 现代CSS特性，Flexbox/Grid布局
- **JavaScript (ES6+)**: 原生JavaScript，无依赖框架
- **GSAP**: 专业动画库（通过CDN引入）

### 设计特色
- **深色主题**: 突出视频内容的专业设计
- **渐变色彩**: 紫色系品牌配色
- **玻璃态效果**: 现代化视觉效果
- **流畅动画**: 滚动触发和交互动画

## 🔧 VS Code 开发环境设置

### 1. 必需的VS Code扩展

安装以下推荐扩展以获得最佳开发体验：

```bash
# 基础扩展
- Live Server                 # 本地开发服务器
- HTML CSS Support           # HTML/CSS智能提示
- JavaScript (ES6) code snippets # JS代码片段
- Prettier - Code formatter  # 代码格式化
- Auto Rename Tag           # HTML标签自动重命名

# 可选扩展
- Bracket Pair Colorizer    # 括号配对着色
- GitLens                   # Git增强功能
- Material Icon Theme       # 文件图标主题
- One Dark Pro             # 深色主题
```

### 2. VS Code 工作区配置

在项目根目录创建 `.vscode/settings.json`：

```json
{
    "liveServer.settings.port": 3000,
    "liveServer.settings.CustomBrowser": "chrome",
    "liveServer.settings.donotShowInfoMsg": true,
    "emmet.includeLanguages": {
        "javascript": "javascriptreact"
    },
    "prettier.singleQuote": true,
    "prettier.semi": true,
    "prettier.tabWidth": 4,
    "editor.formatOnSave": true,
    "editor.codeActionsOnSave": {
        "source.fixAll": true
    }
}
```

### 3. 推荐的VS Code快捷键

```bash
# 开发常用快捷键
Ctrl + Shift + P    # 命令面板
Ctrl + `            # 打开终端
Ctrl + Shift + L    # 选择所有相同内容
Alt + Shift + F     # 格式化代码
Ctrl + /            # 注释/取消注释
F12                 # 转到定义
Ctrl + Shift + F    # 全局搜索
```

## 🚀 本地开发和测试

### 方法一：使用Live Server扩展（推荐）

1. **安装Live Server扩展**
2. **右键点击 `index.html`**
3. **选择 "Open with Live Server"**
4. **浏览器自动打开 `http://localhost:3000`**

### 方法二：使用Python内置服务器

```bash
# 在项目根目录运行
python -m http.server 8000
# 或者使用Python 3
python3 -m http.server 8000

# 浏览器打开 http://localhost:8000
```

### 方法三：使用Node.js服务器

```bash
# 全局安装http-server
npm install -g http-server

# 在项目目录运行
http-server -p 8000

# 浏览器打开 http://localhost:8000
```

## 📝 源代码详细说明

### HTML结构 (index.html)

#### 1. 文档头部
```html
<!DOCTYPE html>
<html lang="en" id="html-root">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ainois Studio - 2D/3D Animation & Motion Graphics</title>
    
    <!-- SEO优化 -->
    <meta name="description" content="...">
    <meta name="keywords" content="...">
    
    <!-- 字体和样式 -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Playfair+Display:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
</head>
```

#### 2. 主要页面结构
```html
<body>
    <!-- 语言切换按钮 -->
    <div class="language-toggle">...</div>
    
    <!-- 导航栏 -->
    <nav class="navbar" id="navbar">...</nav>
    
    <!-- 主要内容区域 -->
    <main>
        <section class="hero">...</section>        <!-- 首页横幅 -->
        <section class="services">...</section>    <!-- 服务展示 -->
        <section class="about">...</section>       <!-- 关于我们 -->
        <section class="portfolio">...</section>   <!-- 作品集 -->
        <section class="contact">...</section>     <!-- 联系我们 -->
    </main>
    
    <!-- 页脚 -->
    <footer class="footer">...</footer>
    
    <!-- 视频模态框 -->
    <div class="video-modal" id="video-modal">...</div>
    
    <!-- JavaScript文件 -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/ScrollTrigger.min.js"></script>
    <script src="js/script.js"></script>
</body>
```

### CSS样式 (css/style.css)

#### 1. 基础样式重置
```css
/* 全局重置和基础样式 */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Inter', sans-serif;
    background-color: #0a0a0a;
    color: #333;
    overflow-x: hidden;
}
```

#### 2. 关键CSS类说明

**导航栏样式**
```css
.navbar {
    position: fixed;           /* 固定定位 */
    background: rgba(10, 10, 10, 0.95);  /* 半透明背景 */
    backdrop-filter: blur(20px);         /* 毛玻璃效果 */
    z-index: 1000;            /* 层级控制 */
}
```

**响应式网格布局**
```css
.services-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
    gap: 2rem;
}
```

**动画效果**
```css
@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(30px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}
```

### JavaScript功能 (js/script.js)

#### 1. 多语言系统
```javascript
// 语言翻译对象
const translations = {
    en: { /* 英文翻译 */ },
    zh: { /* 中文翻译 */ }
};

// 语言切换函数
function switchLanguage(lang) {
    currentLang = lang;
    // 更新所有可翻译元素
    document.querySelectorAll('[data-en]').forEach(element => {
        // 翻译逻辑
    });
}
```

#### 2. GSAP动画初始化
```javascript
function initializeGSAP() {
    gsap.registerPlugin(ScrollTrigger);
    
    // 首页动画时间线
    gsap.timeline()
        .from('.hero-title-main', { duration: 1, y: 50, opacity: 0 })
        .from('.hero-title-sub', { duration: 0.8, y: 30, opacity: 0 }, '-=0.5');
}
```

#### 3. YouTube视频集成
```javascript
function openVideoModal(videoId) {
    const iframe = document.createElement('iframe');
    iframe.src = `https://www.youtube.com/embed/${videoId}?autoplay=1&rel=0`;
    iframe.allowFullscreen = true;
    
    videoContainer.appendChild(iframe);
    videoModal.classList.add('active');
}
```

## 🎨 自定义和修改指南

### 1. 修改品牌颜色

在 `css/style.css` 中找到主要颜色变量：

```css
/* 主要品牌色 - 紫色渐变 */
background: linear-gradient(135deg, #6366f1, #8b5cf6);

/* 修改为其他颜色，例如蓝色渐变 */
background: linear-gradient(135deg, #3b82f6, #1d4ed8);

/* 或者绿色渐变 */
background: linear-gradient(135deg, #10b981, #059669);
```

### 2. 添加新的服务项目

在 `index.html` 的服务部分添加新卡片：

```html
<div class="service-card">
    <div class="service-icon">
        <!-- 添加新的SVG图标 -->
        <svg>...</svg>
    </div>
    <h3 class="service-title" data-en="New Service" data-zh="新服务">New Service</h3>
    <p class="service-description" data-en="Service description" data-zh="服务描述">Service description</p>
</div>
```

### 3. 修改作品集内容

更新 `index.html` 中的作品集项目：

```html
<div class="portfolio-item" data-category="2d-animation">
    <div class="portfolio-video">
        <div class="video-placeholder" data-video-id="YOUR_YOUTUBE_VIDEO_ID">
            <img src="https://img.youtube.com/vi/YOUR_VIDEO_ID/maxresdefault.jpg" alt="Video thumbnail">
            <div class="play-button">
                <svg>...</svg>
            </div>
        </div>
    </div>
    <div class="portfolio-info">
        <h3 class="portfolio-title">Your Project Title</h3>
        <p class="portfolio-description">Project description</p>
        <div class="portfolio-tags">
            <span class="tag">Tag1</span>
            <span class="tag">Tag2</span>
        </div>
    </div>
</div>
```

### 4. 更新联系信息

修改 `index.html` 中的联系信息：

```html
<div class="contact-item">
    <div class="contact-icon">
        <svg>...</svg>
    </div>
    <div class="contact-text">
        <h4>Email</h4>
        <p><a href="mailto:your-email@domain.com">your-email@domain.com</a></p>
    </div>
</div>
```

### 5. 添加新的语言翻译

在 `js/script.js` 中的 `translations` 对象添加新语言：

```javascript
const translations = {
    en: { /* 英文翻译 */ },
    zh: { /* 中文翻译 */ },
    ja: { /* 日文翻译 */ },
    ko: { /* 韩文翻译 */ }
};
```

## 🔍 调试和测试

### 1. 浏览器开发者工具

**打开方式**：
- Chrome/Edge: `F12` 或 `Ctrl+Shift+I`
- Firefox: `F12` 或 `Ctrl+Shift+I`
- Safari: `Cmd+Option+I` (Mac)

**常用面板**：
- **Elements**: 检查HTML结构和CSS样式
- **Console**: 查看JavaScript错误和日志
- **Network**: 监控资源加载
- **Application**: 检查本地存储和缓存

### 2. 响应式设计测试

**设备模拟**：
1. 打开开发者工具
2. 点击设备图标或按 `Ctrl+Shift+M`
3. 选择不同设备尺寸测试

**常用断点**：
- 手机: 320px - 768px
- 平板: 768px - 1024px
- 桌面: 1024px+

### 3. 性能优化检查

**Lighthouse审计**：
1. 打开Chrome开发者工具
2. 切换到 "Lighthouse" 面板
3. 点击 "Generate report"
4. 查看性能、可访问性、SEO评分

### 4. 常见问题排查

**JavaScript错误**：
```javascript
// 在console中检查错误
console.error('Error message');

// 使用try-catch捕获错误
try {
    // 可能出错的代码
} catch (error) {
    console.error('Caught error:', error);
}
```

**CSS样式问题**：
```css
/* 使用border调试布局 */
.debug {
    border: 1px solid red !important;
}

/* 检查元素是否被正确选中 */
.test-selector {
    background: yellow !important;
}
```

## 📱 移动端优化

### 1. 触摸友好设计
```css
/* 增加触摸目标大小 */
.btn, .nav-link {
    min-height: 44px;
    min-width: 44px;
}

/* 优化触摸反馈 */
.btn:active {
    transform: scale(0.98);
}
```

### 2. 移动端特定样式
```css
@media (max-width: 768px) {
    .hero-title-main {
        font-size: 2.5rem;
    }
    
    .container {
        padding: 0 1rem;
    }
}
```

## 🚀 部署指南

### 1. 静态网站托管服务

**推荐平台**：
- **Netlify**: 免费SSL，自动部署
- **Vercel**: 优秀的性能，易于使用
- **GitHub Pages**: 免费，与Git集成
- **Firebase Hosting**: Google服务，全球CDN

### 2. 部署步骤（以Netlify为例）

1. **注册Netlify账户**
2. **拖拽项目文件夹到Netlify**
3. **自动获得HTTPS域名**
4. **可选：绑定自定义域名**

### 3. 自定义域名配置

```bash
# DNS设置示例
A记录: @ -> 104.198.14.52
CNAME: www -> your-site.netlify.app
```

## 📊 SEO优化

### 1. Meta标签优化
```html
<meta name="description" content="Ainois Studio - Professional 2D/3D Animation and Motion Graphics Studio in Singapore">
<meta name="keywords" content="animation, motion graphics, 2D animation, 3D animation, Singapore">
<meta property="og:title" content="Ainois Studio - Animation & Motion Graphics">
<meta property="og:description" content="Professional animation studio specializing in 2D/3D animation and motion graphics">
<meta property="og:image" content="https://your-domain.com/og-image.jpg">
```

### 2. 结构化数据
```html
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Organization",
  "name": "Ainois Studio",
  "url": "https://your-domain.com",
  "description": "Professional animation and motion graphics studio"
}
</script>
```

## 🔧 维护和更新

### 1. 定期检查
- **链接有效性**: 确保所有链接正常工作
- **图片加载**: 检查图片是否正常显示
- **表单功能**: 测试联系表单提交
- **跨浏览器兼容性**: 在不同浏览器测试

### 2. 内容更新
- **作品集**: 定期添加新的项目案例
- **服务信息**: 更新服务描述和价格
- **联系信息**: 确保联系方式准确
- **团队信息**: 更新团队成员介绍

### 3. 性能监控
- **页面加载速度**: 使用Google PageSpeed Insights
- **用户体验**: 收集用户反馈
- **搜索排名**: 监控SEO表现

## 📞 技术支持

如果在开发过程中遇到问题，可以：

1. **查看浏览器控制台错误信息**
2. **检查网络请求是否正常**
3. **验证HTML/CSS/JS语法**
4. **测试不同浏览器兼容性**
5. **查阅相关技术文档**

## 🎉 总结

这个Ainois Studio网站项目采用了现代化的前端技术栈，具有专业的设计和完善的功能。通过本指南，您可以：

- ✅ 理解项目结构和技术架构
- ✅ 使用VS Code进行高效开发
- ✅ 自定义和修改网站内容
- ✅ 进行本地测试和调试
- ✅ 部署到生产环境
- ✅ 维护和优化网站性能

希望这个开发指南能帮助您更好地理解和使用这个专业的动画工作室网站！

